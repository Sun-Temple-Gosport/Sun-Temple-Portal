import './globals.css'
export const metadata={title:'Sun Temple Gosport',description:'Buy and manage tanning minutes'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
